/*
 * Test the C version of libpq, the PostgreSQL frontend library.
 */
#include <iostream>
#include <libpq-fe.h>

void exit_nicely(PGconn *pConn);

int main() {

    const std::string server = "studentpsql.miun.se";
    const std::string port = "5432";
    const std::string dbname = "your_studentid";
    const std::string user = "your_studentid";
    const std::string pass = "";
    const std::string conninfo = "host=" + server + " port=" + port + " dbname=" + dbname + " user=" + user + " password=" + pass;

    PGconn     *conn;
    PGresult   *res;

    std::cout << "Test of PostgreSQL C library" << std::endl;

    /* Make a conn to the database */
    conn = PQconnectdb(conninfo.c_str());

    /* Check to see that the backend conn was successfully made */
    if (PQstatus(conn) != CONNECTION_OK)
    {
        fprintf(stderr, "Connection to database failed: %s",
                PQerrorMessage(conn));
        exit_nicely(conn);
    }

    std::cout << std::endl << "Connected to PostgreSQL on " << server.c_str() << std::endl;

    /* Set always-secure search path, so malicious users can't take control. */
    res = PQexec(conn,
                 "SELECT pg_catalog.set_config('search_path', 'sportsclub8', false)");
    if (PQresultStatus(res) != PGRES_TUPLES_OK)
    {
        fprintf(stderr, "SET failed: %s", PQerrorMessage(conn));
        PQclear(res);
        exit_nicely(conn);
    }

    /*
     * Should PQclear PGresult whenever it is no longer needed to avoid memory
     * leaks
     */
    PQclear(res);

    /*
     * Our test case here involves using a cursor, for which we must be inside
     * a transaction block.  We could do the whole thing with a single
     * PQexec() of "select * from person", but that's too trivial to make
     * a good example.
     */

    /* Start a transaction block */
    res = PQexec(conn, "BEGIN");
    if (PQresultStatus(res) != PGRES_COMMAND_OK)
    {
        fprintf(stderr, "BEGIN command failed: %s", PQerrorMessage(conn));
        PQclear(res);
        exit_nicely(conn);
    }
    PQclear(res);

    /*
     * Fetch all persons
     */
    res = PQexec(conn, "DECLARE allPersons CURSOR FOR "
                       "select förnamn, efternamn, gatuadress, person.postnr, postort, epost "
                       "from person, postort "
                       "where person.postnr = postort.postnr");
    if (PQresultStatus(res) != PGRES_COMMAND_OK)
    {
        fprintf(stderr, "DECLARE CURSOR failed: %s", PQerrorMessage(conn));
        PQclear(res);
        exit_nicely(conn);
    }
    PQclear(res);

    res = PQexec(conn, "FETCH ALL in allPersons");
    if (PQresultStatus(res) != PGRES_TUPLES_OK)
    {
        fprintf(stderr, "FETCH ALL failed: %s", PQerrorMessage(conn));
        PQclear(res);
        exit_nicely(conn);
    }

    std::cout << std::endl << "All persons in Sportsclub8" << std::endl;
    std::cout << "--------------------------" << std::endl;

    /* first, print out the attribute names */
    int nFields = PQnfields(res);
    int i;
    for (i = 0; i < nFields; i++)
        printf("%-17s", PQfname(res, i));
    printf("\n");

    /* next, print out the rows */
    for (i = 0; i < PQntuples(res); i++)
    {
        int j;
        for (j = 0; j < nFields; j++)
            printf("%-17s", PQgetvalue(res, i, j));
        printf("\n");
    }

    PQclear(res);

    /* close the cursor ... we don't bother to check for errors ... */
    res = PQexec(conn, "CLOSE allPersons");
    PQclear(res);

    /* end the transaction */
    res = PQexec(conn, "END");
    PQclear(res);

    /* close the conn to the database and cleanup */
    PQfinish(conn);

    return 0;
}


static void exit_nicely(PGconn *conn)
{
    PQfinish(conn);
    exit(1);
}
